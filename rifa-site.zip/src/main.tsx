
import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import RifaPage from './RifaPage'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RifaPage />
  </React.StrictMode>,
)
